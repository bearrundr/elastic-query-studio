import * as v2_4_6 from './v2_4_6';
import * as v5_6_4 from './v5_6_4';
import * as v6_0_0 from './v6_0_0';

export default {
    '2.4.6': v2_4_6,
    '5.6.4': v5_6_4,
    '6.0.0': v6_0_0,
};
